# Dummy Probes 

## Description

This folder is to put the processes that will simulate our probes. Would be independent of the backend so eventually could be moved to an upper fodler, by now let leave it here.

